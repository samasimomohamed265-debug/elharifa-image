import { useState } from "react";
import "./App.css";

const IMAGE_URL =
  "https://raw.githubusercontent.com/samasimomohamed265-debug/elharifa-image/main/";

const menuData = [
  {
    category: "الساندوتشات",
    image: `${IMAGE_URL}sandwiches.jpg`,
    items: [
      { name: "كبدة اسكندراني", price: 33 },
      { name: "سجق اسكندراني", price: 45 },
      { name: "كفتة", price: 45 },
      { name: "بطاطس سادة", price: 25 },
      { name: "بطاطس موتزاريلا", price: 35 },
    ],
  },
  {
    category: "مكرونات",
    image: `${IMAGE_URL}mixed-pasta.jpg`,
    items: [
      { name: "مكرونة سادة", price: 40 },
      { name: "مكرونة كبدة", price: 65 },
      { name: "مكرونة سجق اسكندراني", price: 65 },
      { name: "مكرونة مكس كبدة وسجق", price: 65 },
      { name: "مكرونة فاهيتا فراخ", price: 70 },
    ],
  },
  {
    category: "مكرونة تشيز",
    image: `${IMAGE_URL}cheese-pasta.jpg`,
    items: [
      { name: "ماك تشيز سادة", price: 80 },
      { name: "ماك كريسبى تشيكن", price: 130 },
      { name: "ماك سموكي باربيكيو", price: 130 },
      { name: "ماك هوت تشيلي", price: 130 },
    ],
  },
  {
    category: "الطلبات",
    image: `${IMAGE_URL}orders.jpg`,
    items: [
      { name: "طلب كبدة اسكندراني", price: 90 },
      { name: "طلب سجق اسكندراني", price: 115 },
      { name: "طلب مكس كبدة وسجق", price: 115 },
    ],
  },
  {
    category: "الحواوشي",
    image: `${IMAGE_URL}hawawshi.jpg`,
    items: [
      { name: "حواوشي سادة", price: 45 },
      { name: "حواوشي موتزاريلا", price: 55 },
      { name: "حواوشي شيدر", price: 55 },
      { name: "حواوشي مكس سجق", price: 60 },
    ],
  },
  {
    category: "برجر (الفراخ)",
    image: `${IMAGE_URL}chicken-burger.jpg`,
    items: [
      { name: "رانش تشيكن", price: 135 },
      { name: "تشيكن الحريفة", price: 150 },
      { name: "باربيكيو تشيكن", price: 135 },
      { name: "فاهيتا فراخ", price: 55 },
      { name: "فاهيتا فراخ موتزاريلا", price: 65 },
    ],
  },
  {
    category: "برجر (اللحم)",
    image: `${IMAGE_URL}beef-burger.jpg`,
    items: [
      { name: "باربيكيو برجر", price: 130 },
      { name: "تشيلي برجر", price: 130 },
      { name: "دابل برجر", price: 180 },
    ],
  },
  {
    category: "الإضافات",
    image: `${IMAGE_URL}extras.jpg`,
    items: [
      { name: "باكت بطاطس", price: 30 },
      { name: "باكت بطاطس شيدر", price: 35 },
      { name: "باكت بطاطس صوصات", price: 40 },
      { name: "كاتشب", price: 10 },
      { name: "باربيكيو", price: 10 },
      { name: "شيدر", price: 10 },
      { name: "تاكو", price: 10 },
      { name: "طماطم مخللة", price: 10 },
      { name: "مخلل", price: 10 },
    ],
  },
];

function App() {
  const [page, setPage] = useState("home");
  const [activeCategory, setActiveCategory] = useState(null);
  const [cart, setCart] = useState([]);

  const [deliveryMethod, setDeliveryMethod] = useState("delivery");

  const [customer, setCustomer] = useState({
    name: "",
    phone: "",
    address: "",
    notes: "",
  });

  const currentCategory = menuData.find(
    (section) => section.category === activeCategory
  );

  function addToCart(item) {
    setCart((oldCart) => {
      const existing = oldCart.find(
        (cartItem) =>
          cartItem.name === item.name &&
          cartItem.category === activeCategory
      );

      if (existing) {
        return oldCart.map((cartItem) =>
          cartItem.name === item.name &&
          cartItem.category === activeCategory
            ? {
                ...cartItem,
                quantity: cartItem.quantity + 1,
              }
            : cartItem
        );
      }

      return [
        ...oldCart,
        {
          ...item,
          category: activeCategory,
          quantity: 1,
        },
      ];
    });
  }

  function increaseItem(item) {
    setCart((oldCart) =>
      oldCart.map((cartItem) =>
        cartItem.name === item.name &&
        cartItem.category === item.category
          ? {
              ...cartItem,
              quantity: cartItem.quantity + 1,
            }
          : cartItem
      )
    );
  }

  function decreaseItem(item) {
    setCart((oldCart) =>
      oldCart
        .map((cartItem) =>
          cartItem.name === item.name &&
          cartItem.category === item.category
            ? {
                ...cartItem,
                quantity: cartItem.quantity - 1,
              }
            : cartItem
        )
        .filter((cartItem) => cartItem.quantity > 0)
    );
  }

  const cartCount = cart.reduce(
    (total, item) => total + item.quantity,
    0
  );

  const cartTotal = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  function openCategory(category) {
    setActiveCategory(category);
    setPage("menu");
  }

  function openCheckout() {
    if (cart.length === 0) return;
    setPage("checkout");
  }

  function sendWhatsApp() {
    if (!customer.name.trim() || !customer.phone.trim()) {
      alert("من فضلك اكتب الاسم ورقم الموبايل");
      return;
    }

    if (
      deliveryMethod === "delivery" &&
      !customer.address.trim()
    ) {
      alert("من فضلك اكتب العنوان بالتفصيل");
      return;
    }

    const phone = "01113531982";

    /* =========================
       تفاصيل الطلب في واتساب
       ========================= */

    const orderText = cart
      .map(
        (item, index) =>
          `${index + 1}. ${item.name} × ${item.quantity}  |  الإجمالي: ${
            item.price * item.quantity
          } ج`
      )
      .join("\n");

    const addressLine =
      deliveryMethod === "delivery"
        ? `📍 العنوان: ${customer.address}`
        : "";

    const message = `🍔 طلب جديد من منيو الحريفة
✦━━━━━━━━━━━━━━━━✦

👤 بيانات العميل
الاسم: ${customer.name}
📱 الموبايل: ${customer.phone}
${addressLine}

✦━━━━━━━━━━━━━━━━✦
🍽️ تفاصيل الطلب

${orderText}

✦━━━━━━━━━━━━━━━━✦
💰 الإجمالي: ${cartTotal} ج

${
  deliveryMethod === "delivery"
    ? "🚚 طريقة الاستلام: توصيل"
    : "🏪 طريقة الاستلام: استلام من الفرع"
}
📝 ملاحظات: ${customer.notes.trim() || "لا يوجد"}

✦━━━━━━━━━━━━━━━━✦
❤️ شكرًا لاختياركم الحريفة`;

    window.open(
      `https://wa.me/2${phone}?text=${encodeURIComponent(message)}`,
      "_blank"
    );
  }

  return (
    <div className="app" dir="rtl">

      {/* الرئيسية */}
      {page === "home" && (
        <main className="home-page">

          <div className="logo-box">
            <img
              src={`${IMAGE_URL}logo.png.jpeg`}
              alt="الحريفة"
              className="logo"
            />
          </div>

          <h1 className="restaurant-name">
            الحريفة
          </h1>

          <p className="restaurant-tagline">
            أصل الأكل الحرش
          </p>

          <div className="restaurant-contact">
            <p>📞 0402378099</p>
            <p>📍 المشحمه، أمام فرن أبو راضي</p>
          </div>

          <p className="restaurant-description">
            طعم معمول للحريفة ❤️
          </p>

          <button
            className="main-button"
            onClick={() => setPage("categories")}
          >
            شوف المنيو
          </button>

          <button
            className="social-button"
            onClick={() => setPage("socials")}
          >
            موقعنا وصفحاتنا
          </button>

        </main>
      )}

      {/* الصفحات */}
      {page === "socials" && (
        <main className="socials">

          <button
            className="back-button"
            onClick={() => setPage("home")}
          >
            ← رجوع
          </button>

          <h2 className="section-title">
            موقعنا وصفحاتنا
          </h2>

          <a
            className="social-card"
            href="https://www.tiktok.com/@elharifh5?_r=1&_t=ZS-99pFoHqqx2i"
            target="_blank"
            rel="noreferrer"
          >
            <span className="social-icon">TikTok</span>
            <span>تيك توك</span>
          </a>

          <a
            className="social-card"
            href="https://www.instagram.com/elharifh?stkn=b3EydWUxM2F0NG1u"
            target="_blank"
            rel="noreferrer"
          >
            <span className="social-icon">Instagram</span>
            <span>إنستجرام</span>
          </a>

          <a
            className="social-card"
            href="https://www.facebook.com/share/1EAFTn3KKE/?mibextid=wwXIfr"
            target="_blank"
            rel="noreferrer"
          >
            <span className="social-icon">Facebook</span>
            <span>فيسبوك</span>
          </a>

          <a
            className="social-card"
            href="https://wa.me/201113531982"
            target="_blank"
            rel="noreferrer"
          >
            <span className="social-icon">WhatsApp</span>
            <span>واتساب</span>
          </a>

        </main>
      )}

      {/* الأقسام */}
      {page === "categories" && (
        <main>

          <header className="header">

            <div>
              <h1>الحريفة</h1>
              <p>أصل الأكل الحرش ❤️</p>
            </div>

            <button
              className="cart-icon"
              onClick={() => setPage("cart")}
            >
              🛒
              {cartCount > 0 && (
                <span>{cartCount}</span>
              )}
            </button>

          </header>

          <h2 className="section-title">
            اختار قسم
          </h2>

          <div className="categories">

            {menuData.map((section) => (
              <button
                key={section.category}
                className="category-card"
                onClick={() =>
                  openCategory(section.category)
                }
              >
                <img
                  src={section.image}
                  alt={section.category}
                  className="category-image"
                />

                <span className="category-name">
                  {section.category}
                </span>
              </button>
            ))}

          </div>

        </main>
      )}

      {/* المنيو */}
      {page === "menu" && currentCategory && (
        <main>

          <header className="header">

            <button
              className="back-button"
              onClick={() => setPage("categories")}
            >
              ← الأقسام
            </button>

            <button
              className="cart-icon"
              onClick={() => setPage("cart")}
            >
              🛒
              {cartCount > 0 && (
                <span>{cartCount}</span>
              )}
            </button>

          </header>

          <div className="category-header">

            <img
              src={currentCategory.image}
              alt={currentCategory.category}
              className="category-header-image"
            />

            <h2 className="section-title">
              {currentCategory.category}
            </h2>

          </div>

          <div className="items">

            {currentCategory.items.map((item) => (
              <div
                className="item-card"
                key={item.name}
              >

                <div className="item-info">

                  <h3>{item.name}</h3>

                  <p>
                    {item.price} جنيه
                  </p>

                </div>

                <button
                  className="add-button"
                  onClick={() => addToCart(item)}
                >
                  +
                </button>

              </div>
            ))}

          </div>

        </main>
      )}

      {/* السلة */}
      {page === "cart" && (
        <main className="cart-page">

          <header className="header">

            <button
              className="back-button"
              onClick={() =>
                activeCategory
                  ? setPage("menu")
                  : setPage("categories")
              }
            >
              ← رجوع
            </button>

            <h2>السلة</h2>

          </header>

          {cart.length === 0 ? (
            <div className="empty-cart">

              <p>السلة فاضية</p>

              <button
                className="main-button"
                onClick={() => setPage("categories")}
              >
                شوف المنيو
              </button>

            </div>
          ) : (
            <>
              {cart.map((item) => (
                <div
                  className="cart-item"
                  key={`${item.category}-${item.name}`}
                >

                  <div className="cart-item-top">

                    <div>
                      <h3 className="cart-item-name">
                        {item.name}
                      </h3>

                      <p className="cart-item-price">
                        {item.price} جنيه
                      </p>
                    </div>

                    <div className="quantity">

                      <button
                        onClick={() =>
                          decreaseItem(item)
                        }
                      >
                        −
                      </button>

                      <span>
                        {item.quantity}
                      </span>

                      <button
                        onClick={() =>
                          increaseItem(item)
                        }
                      >
                        +
                      </button>

                    </div>

                  </div>

                  <p className="cart-line-total">
                    {item.price * item.quantity} جنيه
                  </p>

                </div>
              ))}

              <div className="total-box">
                الإجمالي: {cartTotal} جنيه
              </div>

              <button
                className="confirm-button"
                onClick={openCheckout}
              >
                إتمام الطلب
              </button>

            </>
          )}

        </main>
      )}

      {/* بيانات الطلب */}
      {page === "checkout" && (
        <main className="checkout-page">

          <header className="header">

            <button
              className="back-button"
              onClick={() => setPage("cart")}
            >
              ← السلة
            </button>

            <h2>بيانات الطلب</h2>

          </header>

          <div className="checkout-box">

            <h3>طريقة الاستلام</h3>

            <div className="delivery-options">

              <button
                type="button"
                className={
                  deliveryMethod === "delivery"
                    ? "delivery-option active"
                    : "delivery-option"
                }
                onClick={() =>
                  setDeliveryMethod("delivery")
                }
              >
                🚚
                <span>توصيل</span>
              </button>

              <button
                type="button"
                className={
                  deliveryMethod === "pickup"
                    ? "delivery-option active"
                    : "delivery-option"
                }
                onClick={() =>
                  setDeliveryMethod("pickup")
                }
              >
                🏪
                <span>استلام من الفرع</span>
              </button>

            </div>

            <h3>بيانات العميل</h3>

            <label>الاسم</label>

            <input
              type="text"
              placeholder="اكتب اسمك"
              value={customer.name}
              onChange={(e) =>
                setCustomer({
                  ...customer,
                  name: e.target.value,
                })
              }
            />

            <label>رقم الموبايل</label>

            <input
              type="tel"
              placeholder="01xxxxxxxxx"
              value={customer.phone}
              onChange={(e) =>
                setCustomer({
                  ...customer,
                  phone: e.target.value,
                })
              }
            />

            {deliveryMethod === "delivery" && (
              <>
                <label>العنوان بالتفصيل</label>

                <textarea
                  placeholder="اكتب العنوان بالتفصيل"
                  value={customer.address}
                  onChange={(e) =>
                    setCustomer({
                      ...customer,
                      address: e.target.value,
                    })
                  }
                />
              </>
            )}

            <label>ملاحظات (اختياري)</label>

            <textarea
              placeholder="أي ملاحظات على الطلب؟"
              value={customer.notes}
              onChange={(e) =>
                setCustomer({
                  ...customer,
                  notes: e.target.value,
                })
              }
            />

          </div>

          <div className="order-review">

            <h3>🍽️ تفاصيل الطلب</h3>

            {cart.map((item, index) => (
              <div
                className="review-item"
                key={`${item.category}-${item.name}`}
              >

                <span className="review-name">
                  {index + 1}. {item.name}
                </span>

                <span className="review-quantity">
                  × {item.quantity}
                </span>

                <span className="review-separator">
                  |
                </span>

                <strong>
                  {item.price * item.quantity} ج
                </strong>

              </div>
            ))}

            <div className="review-total">
              💰 الإجمالي: {cartTotal} ج
            </div>

          </div>

          <button
            className="confirm-button"
            onClick={sendWhatsApp}
          >
            💬 تأكيد الطلب وإرساله واتساب
          </button>

        </main>
      )}

      {/* شريط السلة */}
      {cartCount > 0 &&
        page !== "cart" &&
        page !== "checkout" && (
          <div className="cart-bar">

            <div>
              <strong>
                🛒 {cartCount} منتجات
              </strong>

              <p>
                {cartTotal} جنيه
              </p>
            </div>

            <button
              onClick={() => setPage("cart")}
            >
              عرض السلة
            </button>

          </div>
        )}

    </div>
  );
}

export default App;